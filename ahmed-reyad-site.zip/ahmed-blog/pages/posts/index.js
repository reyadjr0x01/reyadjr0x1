import Link from 'next/link';
import { getSortedPostsData } from '../../lib/posts';

export async function getStaticProps() {
  const posts = getSortedPostsData();
  return { props: { posts } };
}

export default function AllPosts({ posts }) {
  return (
    <>
      <header>
        <nav className="nav wrap">
          <div className="brand">0x<span>REYAD</span></div>
          <div className="nav-links">
            <Link href="/#experience">Experience</Link>
            <Link href="/#projects">Projects</Link>
            <Link href="/posts">Writing</Link>
            <Link href="/#contact">Contact</Link>
          </div>
        </nav>
      </header>

      <section className="post-header">
        <div className="wrap">
          <Link href="/" className="back-link">← Back home</Link>
          <div className="post-meta">ARCHIVE</div>
          <h1 className="post-title">All articles</h1>
        </div>
      </section>

      <section>
        <div className="wrap">
          {posts.length === 0 ? (
            <p className="empty-note">No articles published yet.</p>
          ) : (
            <div className="post-list">
              {posts.map((post) => (
                <div className="post-row" key={post.slug}>
                  <div className="date">{post.date}</div>
                  <div>
                    <Link href={`/posts/${post.slug}`} className="title-link">
                      <h3>{post.title}</h3>
                    </Link>
                    <p>{post.summary}</p>
                    {post.tags?.length > 0 && (
                      <div className="tags">
                        {post.tags.map((t) => <span key={t}>{t}</span>)}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <footer>© 2026 Ahmed Mohamed Reyad — All rights reserved</footer>
    </>
  );
}
