import Link from 'next/link';
import { marked } from 'marked';
import { getAllPostSlugs, getPostData } from '../../lib/posts';

export async function getStaticPaths() {
  const paths = getAllPostSlugs();
  return { paths, fallback: false };
}

export async function getStaticProps({ params }) {
  const post = getPostData(params.slug);
  return { props: { post } };
}

export default function Post({ post }) {
  const html = marked.parse(post.content || '');

  return (
    <>
      <header>
        <nav className="nav wrap">
          <div className="brand">0x<span>REYAD</span></div>
          <div className="nav-links">
            <Link href="/#experience">Experience</Link>
            <Link href="/#projects">Projects</Link>
            <Link href="/posts">Writing</Link>
            <Link href="/#contact">Contact</Link>
          </div>
        </nav>
      </header>

      <section className="post-header">
        <div className="wrap">
          <Link href="/posts" className="back-link">← All articles</Link>
          <div className="post-meta">{post.date}</div>
          <h1 className="post-title">{post.title}</h1>
          {post.tags?.length > 0 && (
            <div className="post-tags">
              {post.tags.map((t) => <span key={t}>{t}</span>)}
            </div>
          )}
        </div>
      </section>

      <section>
        <div className="wrap">
          <div className="post-body" dangerouslySetInnerHTML={{ __html: html }} />
        </div>
      </section>

      <footer>© 2026 Ahmed Mohamed Reyad — All rights reserved</footer>
    </>
  );
}
