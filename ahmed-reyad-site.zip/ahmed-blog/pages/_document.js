import { Html, Head, Main, NextScript } from 'next/document';

export default function Document() {
  return (
    <Html lang="en" dir="ltr">
      <Head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link
          href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Space+Grotesk:wght@500;600;700&display=swap"
          rel="stylesheet"
        />
        <meta name="description" content="SOC analyst specializing in detection engineering, incident response, and AI-assisted security operations. Writing on DFIR, SOC automation, and threat detection." />
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}
