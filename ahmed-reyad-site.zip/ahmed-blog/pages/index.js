import Link from 'next/link';
import { getSortedPostsData } from '../lib/posts';

export async function getStaticProps() {
  const posts = getSortedPostsData().slice(0, 5);
  return { props: { posts } };
}

export default function Home({ posts }) {
  return (
    <>
      <header>
        <nav className="nav wrap">
          <div className="brand">0x<span>REYAD</span></div>
          <div className="nav-links">
            <a href="#experience">Experience</a>
            <a href="#projects">Projects</a>
            <a href="#writing">Writing</a>
            <a href="#contact">Contact</a>
          </div>
        </nav>
      </header>

      <section className="hero">
        <div className="wrap">
          <div className="case-tag reveal" style={{ animationDelay: '.05s' }}>STATUS: ACTIVELY MONITORING</div>
          <h1 className="reveal" style={{ animationDelay: '.18s' }}>
            Ahmed Mohamed Reyad — SOC analyst building the <em>AI-assisted</em> SOC.
          </h1>
          <p className="hero-sub reveal" style={{ animationDelay: '.32s' }}>
            I triage alerts, tune detections, and hunt across enterprise SIEM and EDR platforms — and I write about what I learn along the way. Based in Cairo, Egypt.
          </p>
          <div className="hero-cta reveal" style={{ animationDelay: '.46s' }}>
            <a href="#writing" className="btn primary">Read the writing</a>
            <a href="#contact" className="btn ghost">Get in touch</a>
          </div>

          <div className="ticker reveal" style={{ animationDelay: '.6s' }}>
            <div><span>ROLE</span>SOC Analyst</div>
            <div><span>FOCUS</span>Detection &amp; Automation</div>
            <div><span>CERT</span>eCIR (INE, 2025)</div>
            <div><span>BASED IN</span>Cairo, EG</div>
          </div>
        </div>
      </section>

      <section id="experience">
        <div className="wrap">
          <div className="kicker">PROFESSIONAL EXPERIENCE</div>
          <h2>Where I&apos;ve worked</h2>

          <div className="xp">
            <div className="when">Oct 2025 —<br />Present</div>
            <div>
              <h3>ZeroSploitMEA</h3>
              <span className="role">SOC Analyst</span>
              <ul>
                <li>Monitor and investigate security alerts across enterprise SIEM and EDR platforms.</li>
                <li>Improve detection logic and support false-positive reduction initiatives.</li>
                <li>Develop and integrate AI-driven security workflows and agents (Brigade) to support alert triage, investigation, enrichment, analysis, and case handling.</li>
                <li>Integrate security data and capabilities from SIEM, EDR, XDR, SOAR, and other security APIs into automated workflows.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section id="projects">
        <div className="wrap">
          <div className="kicker">PROJECTS</div>
          <h2>What I&apos;ve built</h2>

          <div className="case">
            <div className="id">01</div>
            <div>
              <h3>CyberNerve — AI-Native Security Operations Platform</h3>
              <span className="role">AI Security Automation Engineer</span>
              <p>An AI-native platform designed to augment SOC teams and automate security operations. Built agentic workflows that automate alert triage, investigation, analysis, enrichment, and case handling, integrating SIEM, EDR, XDR, cloud services, and security APIs into one unified SOC workflow.</p>
              <div className="tags"><span>n8n</span><span>AI Agents</span><span>SIEM/EDR/XDR</span></div>
            </div>
          </div>

          <div className="case">
            <div className="id">02</div>
            <div>
              <h3>Falcon Copilot — Chrome Extension</h3>
              <span className="role">AI-Assisted CrowdStrike Falcon Investigation Assistant</span>
              <p>An analyst-facing browser extension that assists SOC analysts during investigations inside CrowdStrike Falcon, connected to an AI-powered investigation backend (Brigade) for contextual assistance. Designed as an analyst copilot — supporting the human investigator, not replacing them.</p>
              <div className="tags"><span>CrowdStrike Falcon</span><span>LogScale</span><span>Chrome Extension</span></div>
            </div>
          </div>
        </div>
      </section>

      <section id="writing">
        <div className="wrap">
          <div className="kicker">WRITING</div>
          <h2>Latest articles</h2>
          <p className="lead">Notes from the SOC floor and the forensics lab — write-ups, detection ideas, and things I learn the hard way.</p>

          {posts.length === 0 ? (
            <p className="empty-note">No articles published yet — the first one will show up here.</p>
          ) : (
            <div className="post-list">
              {posts.map((post) => (
                <div className="post-row" key={post.slug}>
                  <div className="date">{post.date}</div>
                  <div>
                    <Link href={`/posts/${post.slug}`} className="title-link">
                      <h3>{post.title}</h3>
                    </Link>
                    <p>{post.summary}</p>
                    {post.tags?.length > 0 && (
                      <div className="tags">
                        {post.tags.map((t) => <span key={t}>{t}</span>)}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {posts.length > 0 && (
            <div style={{ marginTop: '30px' }}>
              <Link href="/posts" className="btn ghost">View all articles</Link>
            </div>
          )}
        </div>
      </section>

      <section id="skills">
        <div className="wrap">
          <div className="kicker">TECHNICAL SKILLS</div>
          <h2>Tools and disciplines I work in</h2>

          <div className="cap-grid">
            <div className="cap">
              <h3>SIEM &amp; Detection Engineering</h3>
              <ul>
                <li>Splunk, Wazuh, ELK Stack, IBM QRadar</li>
                <li>Detection rule analysis &amp; optimization</li>
                <li>MITRE ATT&amp;CK mapping</li>
                <li>Telemetry coverage validation</li>
                <li>Log correlation &amp; threat hunting</li>
              </ul>
            </div>
            <div className="cap">
              <h3>Endpoint Security (EDR)</h3>
              <ul>
                <li>CrowdStrike Falcon</li>
                <li>Microsoft Defender for Endpoint</li>
                <li>Symantec Endpoint Detection &amp; Response</li>
              </ul>
            </div>
            <div className="cap">
              <h3>Security Automation &amp; Orchestration</h3>
              <ul>
                <li>n8n (SOAR-style workflows)</li>
                <li>AI integration for detection &amp; vulnerability analysis</li>
                <li>API integration (Kibana, Nessus)</li>
              </ul>
            </div>
          </div>

          <div className="two-col">
            <div>
              <h3>Certificates &amp; Courses</h3>
              <ul>
                <li><b>eCIR</b> — eLearnSecurity Certified Incident Responder, INE, 2025</li>
                <li><b>SANS SEC504</b> — Hacker Tools, Techniques, and Incident Handling</li>
                <li><b>SANS SEC555</b> — Detection Engineering and SIEM Analytics</li>
                <li><b>SANS SEC450</b> — Blue Team Fundamentals</li>
                <li><b>Effective Threat Investigator for SOC Analysts</b> — Mostafa Yahia</li>
              </ul>
            </div>
            <div>
              <h3>Education &amp; Languages</h3>
              <ul>
                <li><b>B.Sc. Computer and AI</b> — Sohag University, 2021–2025 (Very Good, 3.04/4)</li>
                <li><b>Arabic</b> — Native</li>
                <li><b>English</b> — Professional working proficiency</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section id="contact">
        <div className="wrap">
          <div className="kicker">CONTACT</div>
          <h2>Open to collaboration and technical discussion</h2>
          <div className="contact-grid">
            <div className="contact-item"><span>EMAIL</span><a href="mailto:reyadjr0x1@gmail.com">reyadjr0x1@gmail.com</a></div>
            <div className="contact-item"><span>LINKEDIN</span><a href="#">Ahmed Reyad</a></div>
            <div className="contact-item"><span>GITHUB</span><a href="#">GitHub</a></div>
            <div className="contact-item"><span>LOCATION</span>Cairo, Egypt</div>
          </div>
        </div>
      </section>

      <footer>© 2026 Ahmed Mohamed Reyad — All rights reserved</footer>
    </>
  );
}
