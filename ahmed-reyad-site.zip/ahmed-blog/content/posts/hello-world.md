---
title: "Hello, World — Why I'm Writing This"
date: "2026-09-12"
summary: "Kicking off a public log of SOC and DFIR write-ups, detection ideas, and lessons from the floor."
tags: ["SOC", "Meta"]
---

This is the first post on the site. Every file in `content/posts/` becomes a page automatically — no rebuild step to remember, no dashboard to log into. Just write, commit, and it's live.

## How this works

Each article is a single Markdown file with a small block of metadata (the "frontmatter") at the top:

```
---
title: "Your article title"
date: "2026-09-12"
summary: "One or two sentences shown in the article list."
tags: ["Tag1", "Tag2"]
---
```

Everything after the second `---` is the article body, written in normal Markdown: headings with `##`, **bold**, *italic*, lists, code blocks, links, and images all work.

## Publishing a new article

1. Go to the `content/posts` folder in the GitHub repository.
2. Click **Add file → Create new file**.
3. Name it something like `my-new-article.md`.
4. Paste the frontmatter block above, edit it, and write the article underneath.
5. Commit directly to the main branch.

Vercel picks up the commit automatically and republishes the site within a minute or two — no further steps needed.
